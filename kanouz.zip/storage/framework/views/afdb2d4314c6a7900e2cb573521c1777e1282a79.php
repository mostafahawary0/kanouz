 
 

<?php $__env->startSection('title','home'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-content">
  
<div class="bg-dash-dark-2 py-4">
              <div class="container-fluid">
                <h2 class="h5 mb-0">Dashboard</h2>
              </div>
            </div> 


  <?php echo e(Auth::guard('admin')->user()->name); ?>

  
 


 <?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kanouz\resources\views/dashboard/home.blade.php ENDPATH**/ ?>