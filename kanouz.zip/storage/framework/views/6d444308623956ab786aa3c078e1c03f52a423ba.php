

<?php $__env->startSection('title','Products'); ?>

<?php $__env->startSection('content'); ?>


<div class="page-content form-page">

<div class="bg-dash-dark-2 py-4">           
<div class="container-fluid">
                <h2 class="h5 mb-0">Products</h2>
              </div>
            </div> 

            <div class="container-fluid py-2">
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 py-3 px-0">
                  <li class="breadcrumb-item"><a href="<?php echo e(route('homedashboard')); ?>">Home</a></li>
                  <li class="breadcrumb-item active"> <a href="<?php echo e(route('show.order')); ?>"> Orders </a> </li>
                  <li class="breadcrumb-item active"> Order page  </li>
                 </ol>
              </nav>
            </div>
            
            <div class="container-fluid"> 
            <div class="row"> 
<table>  
<tr> <td style="width:100px;  height:45px;"> <h4>Name: </h4> </td> <td> <h4><span style="color:#E95F71;">  <?php echo e($orders->name); ?> </span></h4></td> </tr>
<tr> <td style="width:100px; height:45px;"> <h4>Phone: </h4> </td> <td> <h4><span style="color:#E95F71;"> <?php echo e($orders->phone); ?></span></h4></td> </tr>
<tr> <td style="width:100px; height:45px;"> <h4>Country: </h4> </td> <td> <h4><span style="color:#E95F71;"> <?php echo e($orders->country); ?></span></h4></td> </tr>
<tr> <td style="width:100px; height:45px;"> <h4>City: </h4> </td> <td> <h4><span style="color:#E95F71;"> <?php echo e($orders->city); ?></span></h4></td> </tr>
<tr> <td style="width:100px; height:45px;"> <h4>Quantity: </h4> </td> <td> <h4><span style="color:#E95F71;"> <?php echo e($orders->number); ?></span></h4></td> </tr>
<tr> <td style="width:100px; height:45px;"> <h4>Address:</h4> </td> <td> <h4> <span style="color:#E95F71;"> <?php echo e($orders->address); ?></span></h4></td> </tr>
<tr> <td style="width:100px; height:45px;"> <h4> Description: </h4> </td> <td> <h4><span style="color:#E95F71;"> <?php echo e($orders->description); ?></span></h4></td> </tr>
<tr> <td style="width:100px; height:45px;"> <h4> Product: </h4> </td> <td> <h4><span style="color:#E95F71;"> <?php echo e($orders->product); ?></span></h4></td> </tr>
<tr> <td style="width:100px; height:45px;"> <h4> Price: </h4> </td> <td> <h4><span style="color:#E95F71;"> <?php echo e($orders->price); ?></span></h4></td> </tr>
<tr> <td style="width:100px; height:45px;"> <h4> Image: </h4> </td> <td> <h4><span style="color:#E95F71;"> <img src="<?php echo e(asset('image/'.$orders->img)); ?>" style="width:50px; height:50px;" ></span></h4></td> </tr>
<tr> <td style="width:100px; height:45px;"> <h4> Time: </h4> </td> <td><span  style="color:#E95F71;"> <?php echo e(\Carbon\Carbon::parse($orders->created_at)->diffForHumans()); ?> </span> </td> </tr>
</table>
          </div>
          </div>


</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kanouz\resources\views/dashboard/order/order-page.blade.php ENDPATH**/ ?>