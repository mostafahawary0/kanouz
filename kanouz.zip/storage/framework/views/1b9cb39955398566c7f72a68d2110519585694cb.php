

<?php $__env->startSection('title','About us'); ?>

<?php $__env->startSection('content'); ?>


<style>
 .ck-editor__editable[role="textbox"] {
     height: 200px;
 }

 .cke_contents{
    background-color:#FCF1DC;
}
</style>


<div class="page-content form-page">

<div class="bg-dash-dark-2 py-4">           
<div class="container-fluid">
                <h2 class="h5 mb-0">About us</h2>
              </div>
            </div> 

            <div class="container-fluid py-2">
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 py-3 px-0">
                  <li class="breadcrumb-item"><a href="<?php echo e(route('homedashboard')); ?>">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">About us</li>
                </ol>
              </nav>
            </div>
            
            <section class="pt-0"> 
          <div class="container-fluid">

          <div class="col-lg-12">
                <div class="card">
              

                  <div class="card-body pt-10">
                 
                  <?php $__currentLoopData = $Abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $About): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 


                <div class="col-lg-12 text-center">
                 <img src="<?php echo e(asset('image/'.$About->photo)); ?>" style="width:150px;" >
                 <br>  <br>
                <a href="<?php echo e(route('image.about',$About->id)); ?>" class="btn btn-secondary" type="reset">
                    Change image
                </a>
            
                </div>


                <hr style="color:#fff;">
                    
                <?php if($errors->any()): ?>
<div class="col-12">

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="alert alert-danger"><?php echo e($error); ?> </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php endif; ?>


<?php if(session()->has('error')): ?>

<div class="alert alert-danger"><?php echo e(session('error')); ?></div>

<?php endif; ?>



<?php if(session()->has('success')): ?>

<div class="alert alert-success"><?php echo e(session('success')); ?></div>

<?php endif; ?>

                    <form action="<?php echo e(route('update.about')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

               
                    <h3 class="h4 mb-0" style="color:#8A8D93;">Update content</h3> <br>

    <div class="mb-3">
    <label class="form-label" style="color:#fff;">Content in Arabic</label>
    <textarea id="editor" class="<?php $__errorArgs = ['ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ar"> <?php echo $About->contentAR; ?></textarea>
    <?php $__errorArgs = ['ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>   
  </div>

                    <input type="hidden" value="<?php echo e($About->id); ?>" name="id">
                        
    <div class="mb-3">
    <label class="form-label" style="color:#fff;">Content in English</label>
    <textarea id="editor2" class="<?php $__errorArgs = ['en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="en"><?php echo $About->contentEN; ?></textarea>
    <?php $__errorArgs = ['en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
    </div>
                            
                

                      <button class="btn btn-primary" type="submit">Save</button>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </form>

                  </div>
                </div>
              </div>

        </div>
        </section>
 <?php $__env->stopSection(); ?>
 


<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kanouz\resources\views/dashboard/about/about.blade.php ENDPATH**/ ?>