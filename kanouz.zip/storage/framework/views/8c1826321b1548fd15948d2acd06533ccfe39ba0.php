



<?php $__env->startSection('title','About us'); ?>

<?php $__env->startSection('content'); ?>


<style>
 .ck-editor__editable[role="textbox"] {
     height: 200px;
 }

 .cke_contents{
    background-color:#FCF1DC;
}
</style>


<div class="page-content form-page">

<div class="bg-dash-dark-2 py-4">           
<div class="container-fluid">
                <h2 class="h5 mb-0">About us</h2>
              </div>
            </div> 

<div class="container-fluid py-2">
    <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-0 py-3 px-0">
        <li class="breadcrumb-item"><a href="<?php echo e(route('homedashboard')); ?>">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('about')); ?>"> About us</a></li>
        <li class="breadcrumb-item active" aria-current="page">About image</li>
    </ol>
    </nav>
</div>

            <section class="pt-0"> 
          <div class="container-fluid">

          <div class="col-lg-12">
                <div class="card">
                  


                  <div class="card-body pt-10">

                  <?php if($errors->any()): ?>
<div class="col-12">

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="alert alert-danger"><?php echo e($error); ?> </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php endif; ?>


<?php if(session()->has('error')): ?>

<div class="alert alert-danger"><?php echo e(session('error')); ?></div>

<?php endif; ?>



<?php if(session()->has('success')): ?>

<div class="alert alert-success"><?php echo e(session('success')); ?></div>

<?php endif; ?>
 
                    <form action="<?php echo e(route('image.about',$abouts->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>


                    <h3 class="h4 mb-0" style="color:#8A8D93;">Change image</h3> <br>

                  
                    <img src="<?php echo e(asset('image/'.$abouts->photo)); ?>" style="width:150px;" >
                    <br>
                    <br>
                            
                    <div class="mb-3">
                    <label class="form-label" style="color:#fff;">Upload image</label>
                    <input class="form-control" id="formFile" type="file" name="img">
                    </div>

                      <button class="btn btn-primary" type="submit">Save</button>
                     </form>

                  </div>
                </div>
              </div>

        </div>
        </section>
 <?php $__env->stopSection(); ?>
 


<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kanouz\resources\views/dashboard/about/about-image.blade.php ENDPATH**/ ?>