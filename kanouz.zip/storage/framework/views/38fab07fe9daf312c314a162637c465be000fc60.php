

<?php $__currentLoopData = $Abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $About): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

<?php $__env->startSection('title','من نحن'); ?>
<?php $__env->startSection('title','كنوز الطبيعة'); ?>
<?php $__env->startSection('description',$About->contentAR); ?>
<?php $__env->startSection('keywords','الضعف الجنسي , العلاج بالاعشاب , زيوت الشعر'); ?>
<?php $__env->startSection('ogtitle','الضعف الجنسي , العلاج بالاعشاب , زيوت الشعر'); ?>
<?php $__env->startSection('ogimg',asset('web/img/logo.png')); ?>
<?php $__env->startSection('ogdes', $About->contentAR); ?>
<?php $__env->startSection('twitile', 'الضعف الجنسي , العلاج بالاعشاب , زيوت الشعر'); ?>
<?php $__env->startSection('twimg',asset('web/img/logo.png')); ?>
<?php $__env->startSection('twdes', $About->contentAR); ?>




<?php $__env->startSection('content'); ?>
 


       <!-- Product section-->
       <section style="direction: rtl; ">
            <div class="container-fluid">
         
                <div class="row">
                    <div class="col-lg-12" style="padding:50px;"> 
                        <h3 style="font-family: 'cairo1';"> من نحن  </h3> 
                    </div>
                  <div class="col-lg-6" style="font-family: 'cairo1'; font-size:17px; line-height:40px;"> 
                   <?php echo $About->contentAR; ?> 
                </div>  
                  <div class="col-lg-6">   <img src="<?php echo e(asset('image/'.$About->photo)); ?>" style="width:80%;"> </div> 
           
                </div>
            </div>
        </section>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kanouz\resources\views/web/about.blade.php ENDPATH**/ ?>